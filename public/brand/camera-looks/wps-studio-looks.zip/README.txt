World Pickleball Studio — camera looks

Add these JPGs in Zoom (Settings → Background & Effects), macOS Continuity Camera, or your cam app.
Then join Studio with Camera background = Off so the native keyed camera comes through.
